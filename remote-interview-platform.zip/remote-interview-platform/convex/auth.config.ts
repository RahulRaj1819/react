export default {
  providers: [
    {
      domain: "https://climbing-cattle-3.clerk.accounts.dev/",
      applicationID: "convex",
    },
  ],
};
