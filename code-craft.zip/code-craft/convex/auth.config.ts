export default {
  providers: [
    {
      domain: "https://enabling-alien-47.clerk.accounts.dev/",
      applicationID: "convex",
    },
  ],
};
